import{a as t}from"../chunks/entry.DDFppMAe.js";export{t as start};
