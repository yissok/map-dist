import{a as t}from"../chunks/entry.Bb0TEN3-.js";export{t as start};
