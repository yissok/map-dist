import{a as t}from"../chunks/entry.n5X6_JqN.js";export{t as start};
