import"../chunks/disclose-version.Cn-i38oR.js";import{component as p}from"./3.OOg_abS6.js";function e(o){p(o,{})}export{e as component};
