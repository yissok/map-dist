import{a as t}from"../chunks/entry.CX0qSUQ_.js";export{t as start};
