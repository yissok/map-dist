import{a as t}from"../chunks/entry.DERDquHF.js";export{t as start};
