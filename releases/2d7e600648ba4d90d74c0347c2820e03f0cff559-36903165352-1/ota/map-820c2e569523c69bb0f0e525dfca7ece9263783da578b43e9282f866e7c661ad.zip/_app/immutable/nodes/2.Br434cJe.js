import"../chunks/disclose-version.CUjGjnl6.js";import{component as p}from"./3.BrCMJIeT.js";function e(o){p(o,{})}export{e as component};
