import{a as t}from"../chunks/entry.CjTwfqTf.js";export{t as start};
