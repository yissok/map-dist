import{a as t}from"../chunks/entry.CdL23cJD.js";export{t as start};
