var s;const e=((s=globalThis.__sveltekit_177p1ru)==null?void 0:s.base)??"";var a;const t=((a=globalThis.__sveltekit_177p1ru)==null?void 0:a.assets)??e;export{t as a,e as b};
