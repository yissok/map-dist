import"../chunks/disclose-version.CUjGjnl6.js";import{component as p}from"./3.CsJX1C7L.js";function e(o){p(o,{})}export{e as component};
