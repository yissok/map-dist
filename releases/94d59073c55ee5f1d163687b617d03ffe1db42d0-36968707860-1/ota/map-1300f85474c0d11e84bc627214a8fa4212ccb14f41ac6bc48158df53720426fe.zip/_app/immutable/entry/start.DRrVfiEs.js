import{a as t}from"../chunks/entry.BpZrsqZX.js";export{t as start};
