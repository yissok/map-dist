import{a as t}from"../chunks/entry.D7hxM_Ys.js";export{t as start};
