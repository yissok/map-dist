import"../chunks/disclose-version.DdMgqhfK.js";import{component as p}from"./3.DBTphmpz.js";function e(o){p(o,{})}export{e as component};
