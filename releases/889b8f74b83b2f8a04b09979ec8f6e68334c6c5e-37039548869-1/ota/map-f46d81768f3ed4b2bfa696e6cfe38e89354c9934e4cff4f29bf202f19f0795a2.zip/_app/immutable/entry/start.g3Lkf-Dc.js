import{a as t}from"../chunks/entry.DsKoJQ6j.js";export{t as start};
