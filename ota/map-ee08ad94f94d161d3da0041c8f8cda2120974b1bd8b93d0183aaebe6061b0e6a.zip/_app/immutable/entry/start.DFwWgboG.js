import{a as t}from"../chunks/entry.CpKFq8pT.js";export{t as start};
