import"../chunks/disclose-version.DdMgqhfK.js";import{component as p}from"./3.yy8_5qOy.js";function e(o){p(o,{})}export{e as component};
