import{a as t}from"../chunks/entry.CGcV_k7D.js";export{t as start};
