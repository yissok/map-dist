import"../chunks/disclose-version.B2b_C75b.js";import{component as p}from"./3.oOzlFPcu.js";function e(o){p(o,{})}export{e as component};
