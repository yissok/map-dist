import{a as t}from"../chunks/entry.C-fTU9ko.js";export{t as start};
