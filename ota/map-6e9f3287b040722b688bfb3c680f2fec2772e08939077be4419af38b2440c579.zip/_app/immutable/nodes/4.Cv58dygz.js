import{_ as m}from"../chunks/4.DthrWT9j.js";export{m as component};
