import"../chunks/disclose-version.BYMIS1U4.js";import{_ as p}from"../chunks/4.DthrWT9j.js";function e(o){p(o,{})}export{e as component};
