import{a as t}from"../chunks/entry.CR2yL8JC.js";export{t as start};
