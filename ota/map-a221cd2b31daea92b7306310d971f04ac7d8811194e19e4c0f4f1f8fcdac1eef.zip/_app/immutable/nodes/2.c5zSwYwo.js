import"../chunks/disclose-version.Cn-i38oR.js";import{component as p}from"./3.qc_DeIgR.js";function e(o){p(o,{})}export{e as component};
