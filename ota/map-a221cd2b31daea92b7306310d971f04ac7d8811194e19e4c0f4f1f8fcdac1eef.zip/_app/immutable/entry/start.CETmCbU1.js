import{a as t}from"../chunks/entry.Z1nWw4Hp.js";export{t as start};
