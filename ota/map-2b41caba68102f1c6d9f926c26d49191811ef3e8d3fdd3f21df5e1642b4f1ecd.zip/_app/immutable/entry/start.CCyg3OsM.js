import{a as t}from"../chunks/entry.Cto9AtQ1.js";export{t as start};
