import"../chunks/disclose-version.CUjGjnl6.js";import{component as p}from"./3.CKEEwnL9.js";function e(o){p(o,{})}export{e as component};
