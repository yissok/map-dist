import{a as t}from"../chunks/entry.DSGw29XA.js";export{t as start};
