import{a as t}from"../chunks/entry.C2gXniGy.js";export{t as start};
