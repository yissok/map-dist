import{a as t}from"../chunks/entry.DpY9x8ZF.js";export{t as start};
