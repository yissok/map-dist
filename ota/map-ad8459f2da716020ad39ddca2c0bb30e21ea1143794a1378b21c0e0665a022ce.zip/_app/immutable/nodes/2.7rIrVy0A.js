import"../chunks/disclose-version.CgAnHyi6.js";import{component as p}from"./3.CZxCfywk.js";function e(o){p(o,{})}export{e as component};
