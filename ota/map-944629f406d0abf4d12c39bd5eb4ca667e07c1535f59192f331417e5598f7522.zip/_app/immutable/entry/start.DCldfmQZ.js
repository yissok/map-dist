import{a as t}from"../chunks/entry.BZfS-JJP.js";export{t as start};
