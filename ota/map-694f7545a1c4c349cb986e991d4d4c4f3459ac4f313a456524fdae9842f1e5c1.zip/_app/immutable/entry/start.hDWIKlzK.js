import{a as t}from"../chunks/entry.24lEyE3t.js";export{t as start};
