import"../chunks/disclose-version.DdMgqhfK.js";import{component as p}from"./3.p4TH0g_M.js";function e(o){p(o,{})}export{e as component};
