import"../chunks/disclose-version.B2b_C75b.js";import{component as p}from"./3.D-ApaIM_.js";function e(o){p(o,{})}export{e as component};
