import{a as t}from"../chunks/entry.OXbxc6km.js";export{t as start};
